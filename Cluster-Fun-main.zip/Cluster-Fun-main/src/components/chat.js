import React from "react";

const chat = () => {
  return <div>chat</div>;
};

export default chat;
